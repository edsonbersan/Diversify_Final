package com.example.diversify;

public enum InvestmentType {
    STOCKS, OPTIONS, BONDS
}
